-=--------------------------=-
    Performance Monitor
    for Windows 2000/XP+
-=--------------------------=-

Performance Monitor is a small program that shows
you the CPU, Memory, Disk and Network utilization
under Windows NT platforms (2000, XP, ...). 
It's composed by four fully configurable small 
graphs and it can work in the tray area also.
The windows are fully anchorable and by moving the 
"CPU" window you'll move the other attached windows.
PerfMon can become transparent and permits you
to forward left-mouse clicks so you can place it anywhere.
You can also change the program priority saving CPU work ;-)

Installation Notes:
If you are using the zipped package just unpack the .zip in a directory
then launch the perfMon.exe executable ;-)

This Program is freeware. See the file 'license.txt'.

Please send bugs or suggestion at http://www.hexagora.com

--===========================================--
-- Copyright by Lorenzi Davide 2002-2008     --
--===========================================--
---    Download the latest version and      ---
--          additional designs from          --
=           http://www.hexagora.com           =
--===========================================--
